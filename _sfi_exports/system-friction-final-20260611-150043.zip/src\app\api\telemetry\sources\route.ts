import { createKernelRoute } from "@/runtime/api/createKernelRoute";

export const POST = createKernelRoute("telemetry_sources");
